
=======================================
===========HELLO STREAMER==============
=======================================

Hello Streamer. Thanks for playing our game.

The theme is "1 HP". We thought about making
the character only have one health, because
that can be fun and fast paced. Unfortunately,
that can lead to playing like a coward, which
isn't fun or fast paced. It's tough.

So we thought, what if your DAMAGE only had 1
HP? That's weird. But we liked the idea, so we
tried it. We hope you have fun playing it!

=======================================
===============CONTROLS================
=======================================

Keyboard:

WASD -> move around
1, 2, 3, 4 -> summon drones
R -> recall drones
Mouse -> Aim
Left Mouse -> Shoot
Right Mouse -> Nothing, stop clicking it
ESCAPE -> Skip level incase things get broken

Controller:

It's all on-screen in-game moon2S


=======================================
=============OTHER STUFF===============
=======================================

Game programmed using Godot

Art processed in Aseprite

Music and sounds created in REAPER,
or sampled from freesound.org under
Creative Commons License 0 (no copyright)

Instalock Games, 2021
Moonjam - 2021
twitch.tv/MOONMOON

==========================================================
======All immaculate coding done by deadpixelsociety======
===All sick-nasty art and animations done by muffnbuttn===
======All sounds, voices, and tunes done by ICWobbles=====
==========================================================